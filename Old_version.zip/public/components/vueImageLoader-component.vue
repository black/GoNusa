<template>
  <v-lazy-image src="http://lorempixel.com/400/200/" />
</template>

<script>
import VLazyImage from "v-lazy-image";

export default {
  components: {
    VLazyImage
  }
};
</script>